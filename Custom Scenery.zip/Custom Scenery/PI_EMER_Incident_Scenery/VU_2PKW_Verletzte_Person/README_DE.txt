VU-Szenario Template (X-Plane 12 / WED)

Was ist das?
- Ein "fertiges" Paket-SKELETT inkl. konkreter Objekt-Positionen (2 PKW + 1 verletzte Person + Kegel).
- Du kannst es in WED in wenigen Minuten in ein echtes Szenerie-Paket (mit .dsf) exportieren.
- Danach kannst du das komplette Szenario in WED als Block an jede beliebige Koordinate verschieben.

Warum nicht schon als fertige .dsf?
- Eine .dsf ist ein binäres Format, das normalerweise von WED beim "Export Scenery Pack" erzeugt wird.
  Ohne dein installiertes WED/X-Plane-Tooling kann ich hier im Chat keine garantiert kompatible .dsf erzeugen.
  (Der Template-Block ist aber so vorbereitet, dass WED daraus direkt exportieren kann.)

Benötigte Libraries (hast du bereits):
- OpenSceneryX (für PKW + Kegel)
- 3D People Library (für die verletzte Person – ggf. Objektpfad in WED anpassen)

Verwendete bekannte OpenSceneryX-Objektpfade:
- PKW: objects/vehicles/cars/coupe/ford_mustang.obj
- Kegel: objects/furniture/cones_bollards/7.obj

Referenz-Koordinate (Startpunkt):
- Lat 52.52
- Lon 13.405

SCHNELLANLEITUNG (WED):
1) Ordner "VU_2PKW_Verletzte_Person" nach:
   X-Plane 12/Custom Scenery/
2) WED starten
3) File -> New Scenery Package... -> "VU_2PKW_Verletzte_Person" auswählen
4) Im rechten Library-Browser:
   - Suche nach: "objects/vehicles/cars/coupe/ford_mustang.obj" und platziere 2x Autos
   - Suche nach: "objects/furniture/cones_bollards/7.obj" und platziere 6x Kegel
   - Suche in "3D People Library" nach einer liegenden/verletzten Person (falls der Pfad unten nicht existiert)
5) Zum schnellen Platzieren: Öffne "placements.csv" (liegt im Paket) und übernimm Lat/Lon/Heading
   - In WED kannst du bei einem Objekt die "Latitude/Longitude/Heading" Eigenschaften direkt setzen.
6) Wenn alles steht: File -> Export Scenery Pack
   -> Jetzt wird die .dsf erzeugt und das Szenario ist im Simulator sichtbar.

SZENARIO AN EINE ANDERE KOORDINATE SETZEN:
- In WED: Alle Objekte (Hierarchy: Gruppe markieren) -> Drag auf neue Position ODER
- Im Map-Fenster Koordinate oben eingeben (je nach WED-Version) und alles verschieben.

Hinweis zur verletzten Person:
- Der hier eingetragene Pfad ist ein Platzhalter:
  3D_people_library/people/injured/injured_lying_01.obj
  Falls WED "missing resource" meldet: einfach in WED ein passendes "lying/injured" Modell aus der 3D People Library auswählen.

Dateien im Paket:
- placements.csv  (einfach zum Abtippen / Copy&Paste in WED)
- placements.json (die gleichen Daten als JSON)
