VU_1Verletzte_3DPeople_V2

Dieses Incident-Pack ist für PI_EMER_Dispatch_VAR_V12 gebaut.

WICHTIG:
- placements.json nutzt das Schema, das dein Script erwartet:
  { "objects": [ { "path": "...", "x_m": ..., "z_m": ..., "heading_deg": ... }, ... ] }

OBJ-Auflösung:
- Das Script löst "path" zuerst im Szenario-Ordner, dann per Basename-Suche,
  und (wenn INCIDENT_ALLOW_CUSTOM_SCENERY=True) über den Custom-Scenery OBJ-Index.
- Deshalb sind die Pfade hier als Basename angegeben:
  Verletzte_Person.obj / Person_Standing_01.obj ...

Wenn bei dir die stehenden Personen anders heißen:
- Öffne placements.json und ersetze Person_Standing_01/02/03 durch deine echten OBJ-Namen.
