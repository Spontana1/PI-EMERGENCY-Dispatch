#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build +XX+YYYroads_graph.json files from simHeaven DSF network tiles.

Workflow:
- detect X-Plane root from this script location, --xp-root, or by scanning local drives
- detect all zOrtho4XP_+XX+YYY tiles (or use explicit tile args)
- find matching simHeaven network DSF
- call DSFTool --dsf2text
- parse BEGIN_SEGMENT/SHAPE_POINT/END_SEGMENT commands into a road graph
- write <plugin_dir>/+XX+YYYroads_graph.json

Supports X-Plane 11 and X-Plane 12.
This exporter intentionally writes an undirected graph because the current
plugin routes on nodes+adj only.
"""
from __future__ import annotations

import argparse
import json
import math
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
import re

TILE_RE = re.compile(r"^[+-]\d{2}[+-]\d{3}$")
XPLANE_NAME_HINTS = (
    "x-plane 12", "x-plane12", "xplane 12", "xplane12",
    "x-plane 11", "x-plane11", "xplane 11", "xplane11",
)
COMMON_XPLANE_SUBDIRS = (
    Path("Program Files") / "X-Plane 12",
    Path("Program Files (x86)") / "X-Plane 12",
    Path("SteamLibrary") / "steamapps" / "common" / "X-Plane 12",
    Path("Games") / "X-Plane 12",
    Path("X-Plane 12"),
    Path("Program Files") / "X-Plane 11",
    Path("Program Files (x86)") / "X-Plane 11",
    Path("SteamLibrary") / "steamapps" / "common" / "X-Plane 11",
    Path("Games") / "X-Plane 11",
    Path("X-Plane 11"),
)
LIKELY_PARENT_DIRS = ("steamlibrary", "steamapps", "games", "program files", "program files (x86)")



def log(msg: str) -> None:
    print(msg, flush=True)



def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371000.0
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(min(1.0, math.sqrt(a)))



def is_xplane_root(path: Path) -> bool:
    try:
        return (
            (path / "Custom Scenery").is_dir()
            and (path / "Resources").is_dir()
            and ((path / "Resources" / "plugins").is_dir() or (path / "Output").is_dir())
        )
    except Exception:
        return False



def find_xplane_root(start: Path) -> Optional[Path]:
    cur = start.resolve()
    for cand in [cur, *cur.parents]:
        if is_xplane_root(cand):
            return cand
    return None



def iter_windows_drives() -> List[Path]:
    drives: List[Path] = []
    for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        root = Path(f"{letter}:/")
        try:
            if root.exists():
                drives.append(root)
        except Exception:
            continue
    return drives



def find_xplane_root_on_drives(max_depth: int = 4) -> Optional[Path]:
    """Best-effort Windows drive scan for X-Plane 11 or 12."""
    drives = iter_windows_drives()
    if not drives:
        return None

    checked = set()

    def consider(path: Path) -> Optional[Path]:
        try:
            rp = path.resolve()
        except Exception:
            rp = path
        key = str(rp).lower()
        if key in checked:
            return None
        checked.add(key)
        if is_xplane_root(rp):
            return rp
        return None

    for drive in drives:
        for sub in COMMON_XPLANE_SUBDIRS:
            hit = consider(drive / sub)
            if hit:
                return hit

    for drive in drives:
        try:
            for item in drive.iterdir():
                if not item.is_dir():
                    continue
                low = item.name.lower()
                if any(h in low for h in XPLANE_NAME_HINTS):
                    hit = consider(item)
                    if hit:
                        return hit
        except Exception:
            continue

    def walk(base: Path, depth: int) -> Optional[Path]:
        if depth > max_depth:
            return None
        try:
            entries = list(base.iterdir())
        except Exception:
            return None
        dirs = [e for e in entries if e.is_dir()]
        dirs.sort(key=lambda p: (0 if any(h in p.name.lower() for h in XPLANE_NAME_HINTS) else 1, p.name.lower()))
        for item in dirs:
            hit = consider(item)
            if hit:
                return hit
        for item in dirs:
            low = item.name.lower()
            if low in {"windows", "$recycle.bin", "system volume information"}:
                continue
            if depth >= 2 and not (any(h in low for h in XPLANE_NAME_HINTS) or low in LIKELY_PARENT_DIRS):
                continue
            hit = walk(item, depth + 1)
            if hit:
                return hit
        return None

    for drive in drives:
        hit = walk(drive, 0)
        if hit:
            return hit
    return None



def find_plugin_dir(xp_root: Path) -> Path:
    p = xp_root / "Resources" / "plugins" / "PythonPlugins"
    p.mkdir(parents=True, exist_ok=True)
    return p



def detect_tiles(custom_scenery: Path) -> List[str]:
    out = []
    for item in custom_scenery.iterdir():
        if not item.is_dir():
            continue
        name = item.name
        if not name.startswith("zOrtho4XP_"):
            continue
        tok = name[len("zOrtho4XP_"):]
        if TILE_RE.match(tok):
            out.append(tok)
    return sorted(set(out))



def folder_10x10(tile: str) -> str:
    lat = int(tile[:3])
    lon = int(tile[3:])
    lat10 = math.floor(lat / 10.0) * 10
    lon10 = math.floor(lon / 10.0) * 10
    return f"{lat10:+03d}{lon10:+04d}"



def find_simheaven_network_dir(custom_scenery: Path) -> Optional[Path]:
    preferred: List[Path] = []
    fallback: List[Path] = []
    legacy: List[Path] = []
    for item in custom_scenery.iterdir():
        if not item.is_dir():
            continue
        low = item.name.lower()
        if "simheaven" not in low:
            continue
        # XP12 style: simHeaven_X-World_*_network
        if "x-world" in low and "network" in low:
            if any(region in low for region in ("europe", "america", "asia", "africa", "australia")):
                preferred.append(item)
            else:
                fallback.append(item)
            continue
        # XP11 style: simHeaven_X-Europe-2-scenery / X-America-2-extras etc.
        if any(tag in low for tag in ("x-europe", "x-america", "x-africa", "x-asia", "x-australia")):
            if any(tag in low for tag in ("scenery", "roads", "network", "extras")):
                legacy.append(item)
    for bucket in (preferred, fallback, legacy):
        if bucket:
            return sorted(bucket)[0]
    return None



def resolve_dsf_path(network_dir: Path, tile: str) -> Path:
    return network_dir / "Earth nav data" / folder_10x10(tile) / f"{tile}.dsf"



def find_dsftool(explicit: Optional[Path], script_dir: Path, xp_root: Optional[Path]) -> Optional[Path]:
    candidates: List[Path] = []
    if explicit:
        candidates.append(explicit)
    for name in ("DSFTool.exe", "DSFTool", "dsftool.exe", "dsftool"):
        candidates.append(script_dir / name)
        found = shutil.which(name)
        if found:
            candidates.append(Path(found))
    if xp_root is not None:
        candidates.extend([
            xp_root / "DSFTool.exe",
            xp_root / "Resources" / "plugins" / "DSFTool.exe",
            xp_root / "Resources" / "tools" / "DSFTool.exe",
        ])
    for cand in candidates:
        if cand and cand.exists():
            return cand
    return None



def dsf_to_text(dsftool: Path, dsf_path: Path, txt_path: Path) -> None:
    cmd = [str(dsftool), "--dsf2text", str(dsf_path), str(txt_path)]
    log("[DSFTool] " + " ".join(cmd))
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or f"DSFTool failed with code {proc.returncode}")


Coord = Tuple[float, float]



def parse_dsf_text(txt_path: Path) -> Dict[str, object]:
    nodes: Dict[str, Coord] = {}
    adj: Dict[str, List[List[object]]] = {}
    synthetic_idx = 0
    edge_seen = set()

    def add_node(nid: str, lon: float, lat: float) -> None:
        nodes[str(nid)] = (float(lat), float(lon))
        adj.setdefault(str(nid), [])

    def add_edge(a: str, b: str) -> None:
        if a == b or a not in nodes or b not in nodes:
            return
        key = tuple(sorted((str(a), str(b))))
        if key in edge_seen:
            return
        edge_seen.add(key)
        la, loa = nodes[a]
        lb, lob = nodes[b]
        w = round(haversine_m(la, loa, lb, lob), 3)
        adj.setdefault(a, []).append([b, w])
        adj.setdefault(b, []).append([a, w])

    chain: List[str] = []

    def push_point(kind: str, parts: List[str]) -> None:
        nonlocal synthetic_idx, chain
        if kind == "BEGIN_SEGMENT":
            if len(parts) < 7:
                return
            nid = str(parts[3])
            lon = float(parts[4])
            lat = float(parts[5])
            add_node(nid, lon, lat)
            chain = [nid]
            return
        if kind == "BEGIN_SEGMENT_CURVED":
            if len(parts) < 10:
                return
            nid = str(parts[3])
            lon = float(parts[4])
            lat = float(parts[5])
            add_node(nid, lon, lat)
            chain = [nid]
            return
        if kind == "SHAPE_POINT":
            if len(parts) < 4:
                return
            lon = float(parts[1])
            lat = float(parts[2])
        elif kind == "SHAPE_POINT_CURVED":
            if len(parts) < 7:
                return
            lon = float(parts[1])
            lat = float(parts[2])
        elif kind == "END_SEGMENT":
            if len(parts) < 5:
                return
            nid = str(parts[1])
            lon = float(parts[2])
            lat = float(parts[3])
            add_node(nid, lon, lat)
            chain.append(nid)
            return
        elif kind == "END_SEGMENT_CURVED":
            if len(parts) < 8:
                return
            nid = str(parts[1])
            lon = float(parts[2])
            lat = float(parts[3])
            add_node(nid, lon, lat)
            chain.append(nid)
            return
        else:
            return
        synthetic_idx += 1
        nid = f"shape_{synthetic_idx}"
        add_node(nid, lon, lat)
        chain.append(nid)

    with txt_path.open("r", encoding="utf-8", errors="ignore") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            kw = parts[0].upper()
            if kw in ("BEGIN_SEGMENT", "BEGIN_SEGMENT_CURVED"):
                chain = []
                push_point(kw, parts)
            elif kw in ("SHAPE_POINT", "SHAPE_POINT_CURVED"):
                push_point(kw, parts)
            elif kw in ("END_SEGMENT", "END_SEGMENT_CURVED"):
                push_point(kw, parts)
                for a, b in zip(chain[:-1], chain[1:]):
                    add_edge(a, b)
                chain = []

    return {
        "nodes": {nid: [lat, lon] for nid, (lat, lon) in nodes.items()},
        "adj": adj,
        "meta": {
            "format": "simheaven_dsf_export_v1",
            "node_count": len(nodes),
            "edge_count": len(edge_seen),
        },
    }



def write_graph(out_path: Path, graph: Dict[str, object]) -> None:
    out_path.write_text(json.dumps(graph, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")



def build_one(tile: str, xp_root: Path, plugin_dir: Path, network_dir: Path, dsftool: Path, keep_txt: bool = False) -> bool:
    dsf_path = resolve_dsf_path(network_dir, tile)
    if not dsf_path.is_file():
        log(f"[MISS] {tile}: DSF not found: {dsf_path}")
        return False

    out_path = plugin_dir / f"{tile}roads_graph.json"
    with tempfile.TemporaryDirectory(prefix=f"dsf_{tile}_") as tmp:
        txt_path = Path(tmp) / f"{tile}.txt"
        try:
            dsf_to_text(dsftool, dsf_path, txt_path)
            graph = parse_dsf_text(txt_path)
            if not graph.get("nodes") or not graph.get("adj"):
                raise RuntimeError("no road segments parsed from DSF text")
            write_graph(out_path, graph)
            meta = graph.get("meta", {}) if isinstance(graph, dict) else {}
            log(f"[OK] {tile}: nodes={meta.get('node_count')} edges={meta.get('edge_count')} -> {out_path}")
            if keep_txt:
                keep = plugin_dir / f"{tile}.dsf.txt"
                shutil.copy2(txt_path, keep)
                log(f"[KEEP] text dump: {keep}")
            return True
        except Exception as e:
            log(f"[ERR] {tile}: {e}")
            return False



def main(argv: Optional[Iterable[str]] = None) -> int:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Build roads_graph.json from simHeaven DSF")
    parser.add_argument("tiles", nargs="*", help="Tile tokens like +50+006. If omitted, all zOrtho4XP_* tiles are scanned.")
    parser.add_argument("--xp-root", help="Path to X-Plane root")
    parser.add_argument("--simheaven-network", help="Override simHeaven network scenery folder")
    parser.add_argument("--dsftool", help="Path to DSFTool(.exe)")
    parser.add_argument("--keep-txt", action="store_true", help="Keep intermediate DSF text files in plugin dir")
    parser.add_argument("--no-drive-scan", action="store_true", help="Do not scan Windows drives when X-Plane is not found near the script")
    args = parser.parse_args(list(argv) if argv is not None else None)

    xp_root = Path(args.xp_root).resolve() if args.xp_root else find_xplane_root(script_dir)
    if xp_root is None and not args.no_drive_scan:
        log("X-Plane root not found near the script -> scanning drives for X-Plane 11/12...")
        xp_root = find_xplane_root_on_drives()
    if xp_root is None:
        log("X-Plane root not found. Put this script inside your X-Plane folder tree, pass --xp-root, or allow drive scan.")
        return 2

    custom_scenery = xp_root / "Custom Scenery"
    plugin_dir = find_plugin_dir(xp_root)
    network_dir = Path(args.simheaven_network).resolve() if args.simheaven_network else find_simheaven_network_dir(custom_scenery)
    if network_dir is None:
        log("simHeaven network/roads folder not found in Custom Scenery.")
        return 3

    dsftool = find_dsftool(Path(args.dsftool).resolve() if args.dsftool else None, script_dir, xp_root)
    if dsftool is None:
        log("DSFTool not found. Place DSFTool.exe next to this script or pass --dsftool.")
        return 4

    tiles = [t for t in args.tiles if TILE_RE.match(t)]
    if not tiles:
        tiles = detect_tiles(custom_scenery)
    if not tiles:
        log("No zOrtho4XP_+XX+YYY folders found.")
        return 5

    log(f"X-Plane root: {xp_root}")
    log(f"simHeaven network: {network_dir}")
    log(f"DSFTool: {dsftool}")
    log(f"Plugin dir: {plugin_dir}")
    log(f"Tiles: {', '.join(tiles)}")

    ok = 0
    for tile in tiles:
        if build_one(tile, xp_root, plugin_dir, network_dir, dsftool, keep_txt=args.keep_txt):
            ok += 1
    log(f"Done: {ok}/{len(tiles)} tiles built.")
    return 0 if ok else 6


if __name__ == "__main__":
    raise SystemExit(main())
