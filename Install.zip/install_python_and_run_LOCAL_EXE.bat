@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

title simHeaven Python Installer + Builder
color 0F

set "SCRIPT=%~dp0build_simheaven_roads_graph.py"
set "LOG=%~dp0builder_run.log"
set "PY_INSTALLER=%~dp0python-3.14.3-amd64.exe"

> "%LOG%" echo ==================================================
>> "%LOG%" echo simHeaven Python Installer + Builder
>> "%LOG%" echo Start: %DATE% %TIME%
>> "%LOG%" echo Ordner: %CD%
>> "%LOG%" echo ==================================================

echo.
echo ==========================================
echo simHeaven Python Installer + Builder
echo ==========================================
echo.

if not exist "%SCRIPT%" (
    call :tee FEHLER: build_simheaven_roads_graph.py wurde nicht gefunden.
    call :tee Ordner: %CD%
    goto :fail
)

call :find_python
if not errorlevel 1 goto :run

call :tee 1^) Python nicht gefunden.
call :tee Starte jetzt python-3.14.3-amd64.exe ...

if not exist "%PY_INSTALLER%" (
    call :tee FEHLER: python-3.14.3-amd64.exe wurde im gleichen Ordner nicht gefunden.
    goto :fail
)

start /wait "" "%PY_INSTALLER%" /quiet InstallAllUsers=1 PrependPath=1 Include_test=0 Include_pip=1 Include_launcher=1 Shortcuts=1 >> "%LOG%" 2>&1

call :tee 1^) Python installieren - OK
call :tee 2^) Aktualisiere PATH fuer dieses Fenster ...

for /f "usebackq tokens=2,*" %%A in (`reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul ^| find /I "Path"`) do set "SYS_PATH=%%B"
for /f "usebackq tokens=2,*" %%A in (`reg query "HKCU\Environment" /v Path 2^>nul ^| find /I "Path"`) do set "USR_PATH=%%B"

if defined SYS_PATH set "PATH=%SYS_PATH%;%PATH%"
if defined USR_PATH set "PATH=%USR_PATH%;%PATH%"

call :find_python
if not errorlevel 1 goto :run

call :tee FEHLER: Python wurde installiert, aber nicht gefunden.
goto :fail

:run
call :tee 2^) PATH setzen - OK
call :tee 3^) Script starten ...

if /I "%PY_MODE%"=="py" (
    py -3 "%SCRIPT%" %* >> "%LOG%" 2>&1
    set "ERR=%ERRORLEVEL%"
) else (
    "%PY_CMD%" "%SCRIPT%" %* >> "%LOG%" 2>&1
    set "ERR=%ERRORLEVEL%"
)

echo.
if "%ERR%"=="0" (
    call :tee 4^) Fenster bleibt offen - OK
    call :tee Fertig.
    echo.
    echo Log-Datei: "%LOG%"
    pause
    exit /b 0
) else (
    call :tee FEHLER beim Starten des Scripts. Fehlercode: %ERR%
    goto :fail
)

:find_python
set "PY_CMD="
set "PY_MODE="
where py >nul 2>nul
if not errorlevel 1 (
    py -3 --version >> "%LOG%" 2>&1
    if not errorlevel 1 (
        set "PY_CMD=py"
        set "PY_MODE=py"
        exit /b 0
    )
)
where python >nul 2>nul
if not errorlevel 1 (
    for /f "delims=" %%I in ('where python ^| findstr /I /V "WindowsApps"') do (
        set "PY_CMD=%%I"
        set "PY_MODE=python"
        exit /b 0
    )
    python --version >> "%LOG%" 2>&1
    if not errorlevel 1 (
        set "PY_CMD=python"
        set "PY_MODE=python"
        exit /b 0
    )
)
where python3 >nul 2>nul
if not errorlevel 1 (
    python3 --version >> "%LOG%" 2>&1
    if not errorlevel 1 (
        set "PY_CMD=python3"
        set "PY_MODE=python3"
        exit /b 0
    )
)
exit /b 1

:fail
echo.
echo Builder konnte nicht gestartet werden.
echo Log-Datei: "%LOG%"
echo.
pause
exit /b 1

:tee
echo %*
>> "%LOG%" echo %*
exit /b 0
EOF
python3 - <<'PY'
import zipfile, os
base='/mnt/data'
zip_path=os.path.join(base,'simheaven_builder_local_python_installer.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for f in ['build_simheaven_roads_graph.py','build_simheaven_roads_graph.bat','install_python_and_run_LOCAL_EXE.bat','README.txt']:
        p=os.path.join(base,f)
        if os.path.exists(p):
            z.write(p, arcname=f)
print(zip_path)
PY
