@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call "%~dp0install_python_and_run.bat" %*
set ERR=%ERRORLEVEL%
echo.
echo Rueckgabecode: %ERR%
pause
exit /b %ERR%
